﻿using System;

internal class Program
{
    public static double square(double a) 
    {
        if (double.IsNaN(a))
        {
            throw new ArgumentException("Аргумент не является числом.");
        }
        if (a < 0)
        {
            throw new ArgumentException("Нельзя вычислить квадратный корень из отрицательного числа.");
        }
        return Math.Sqrt(a);
    }
    static void Main()
    {
        try 
        {
            Console.WriteLine("Введите число:");
            string input = Console.ReadLine();
            if (string.IsNullOrEmpty(input))
            {
                Console.WriteLine("Произошла ошибка: Ввод пустой или null.");
                Main();
            }

            double n = double.Parse(input);
            double s = square(n);
            Console.WriteLine($"Квадратный корень из {n} равен {s}");
        }
        catch (ArgumentException ex) 
        {
            Console.WriteLine($"Произошла ошибка: {ex.Message}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Произошла ошибка: {ex.Message}");
        }
    }
}