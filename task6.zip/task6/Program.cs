﻿using System;

internal class Program
{
    static void Main()
    {
        Console.WriteLine("Введите название файла:");
        string file = Console.ReadLine();
        String line;
        try
        {
            Console.WriteLine("Содержимое файла:");
            StreamReader sr = new StreamReader("C:\\Users\\Nastya\\стаж\\проекты\\internship\\" + file);
            line = sr.ReadLine();
            if (line.Length > 50)
            {
                Console.WriteLine("Ошибка! Размер файла превышает 50Кб");
                Console.WriteLine();
                Main();
            }
            while (line != null)
            {
                Console.WriteLine(line);
                line = sr.ReadLine();
            }
            sr.Close();
            Console.ReadLine();
        }
        catch (Exception e)
        {
            Console.WriteLine("Ошибка: " + e.Message);
            Console.WriteLine();
            Main();
        }
    }
}